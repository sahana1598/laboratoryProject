import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thyroidreport',
  templateUrl: './thyroidreport.component.html',
  styleUrls: ['./thyroidreport.component.css']
})
export class ThyroidreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
