import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-glucomteryreport',
  templateUrl: './glucomteryreport.component.html',
  styleUrls: ['./glucomteryreport.component.css']
})
export class GlucomteryreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
