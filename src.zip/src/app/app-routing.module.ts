import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DetailsComponent } from './details/details.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { FpageComponent } from './fpage/fpage.component';
import { GlucomteryreportComponent } from './glucomteryreport/glucomteryreport.component';
import { HaematologyreportComponent } from './haematologyreport/haematologyreport.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { SampleComponent } from './sample/sample.component';
import { ThyroidreportComponent } from './thyroidreport/thyroidreport.component';
import { UserpageComponent } from './userpage/userpage.component';
import { ViewdetailsComponent } from './viewdetails/viewdetails.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"getAllSamples",component:DetailsComponent},
  {path:"entersample",component:SampleComponent},
  {path:"haematology",component:HaematologyreportComponent},
  {path:"glucomtery",component:GlucomteryreportComponent},
  {path:"thyroid",component:ThyroidreportComponent},
  {path:"fpage",component:FpageComponent},
  {path:"userpage",component:UserpageComponent},
  {path:"getParticularUser/:_id",component:ViewdetailsComponent},
  {path:"getUser/:_id",component:EditUserComponent}
  // {path:"**",component:}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
