import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fpage',
  templateUrl: './fpage.component.html',
  styleUrls: ['./fpage.component.css']
})
export class FpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
